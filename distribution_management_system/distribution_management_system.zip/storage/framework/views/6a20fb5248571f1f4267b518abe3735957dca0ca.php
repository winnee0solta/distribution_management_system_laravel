

<?php $__env->startSection('content'); ?>
  
<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        <div class="card card-body table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th> 
                        <th>Status</th>
                        <th>Client Name</th>
                        <th>Client Address</th>
                        <th>Client Phone</th>
                        <th>Total Quantity</th>  
                        <th>Total Price</th> 
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($orders)): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td> 
                        <td>
                            <?php if($item['status'] == 'complete'): ?>
                                <span class="badge badge-pill badge-success px-2 py-1"><?php echo e($item['status']); ?></span>
                            <?php else: ?> 
                                <span class="badge badge-pill badge-danger px-2 py-1"><?php echo e($item['status']); ?></span>
                            <?php endif; ?>
                         
                        </td>
                        <td>
                            <?php echo e($item['name']); ?>

                        </td>
                        <td>
                            <?php echo e($item['address']); ?>

                        </td>
                        <td>
                            <?php echo e($item['phone']); ?>

                        </td> 
                        <td>
                            <?php echo e($item['quantity']); ?>

                        </td>
                        <td>
                            <?php echo e($item['total']); ?>

                        </td> 
                       
                        <td>
                            <div class="d-flex">
                                <a href="/dashboard/order/view/<?php echo e($item['user_id']); ?>" class="btn btn-success btn-sm">View</a> 
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/dashboard/order/index.blade.php ENDPATH**/ ?>