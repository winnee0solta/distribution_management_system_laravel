

<?php $__env->startSection('content'); ?>



<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <?php if($product['subcat_id'] != 0): ?>
        <?php
        $subcat = \App\Subcategory::find($product['subcat_id']);
        $cat = \App\Category::find($subcat->category_id);
        ?>
        <li class="breadcrumb-item"> <?php echo e($cat['name']); ?> </li>
        <li class="breadcrumb-item"><a href="/category/<?php echo e($subcat->id); ?>/<?php echo e($subcat->name); ?>"><?php echo e($subcat['name']); ?></a></li>
        <?php endif; ?>

        <li class="breadcrumb-item active" aria-current="page"><?php echo e($product['name']); ?></li>
    </ol>
</nav>

<div class="container card card-body">
    <div class="row ">
        <div class="col-12 col-md-4 mt-2">
            <img src="<?php echo e(asset('/images/products/'.$product['img'])); ?>" class="img-fluid d-block m-auto">
        </div>
        <div class="col-12 col-md-6 mt-2">
            <div>

                <div class="h4 font-weight-bold text-info">
                    <?php echo e($product['name']); ?>

                </div>
                <div class="h6 ">
                    <span class="text-danger">
                        Rs <?php echo e($product['price']); ?></span>
                    <br>
                    Quantity - <?php echo e($product['quantity']); ?>

                </div>
                <div class="h5  s">
                </div>
                <div>
                    <p>
                        <?php echo e($product['desc']); ?>

                    </p>
                </div>

                <div>
                    <?php if($product['quantity'] != 0): ?>

                    <form action="/add-to-cart" method="POST"  >
                        <?php echo csrf_field(); ?> 
                        <input name="product_id" value="<?php echo e($product->id); ?>" type="hidden" >
                        <div class="form-group">
                            <label>Product Quantity</label> 
                        <input name="quantity" required type="number" min="1" max="<?php echo e($product['quantity']); ?>" class="form-control" value="1" style="width: 50%">
                        </div> 
                        <button type="submit" class="btn btn-danger">Add To Cart</button>
                    </form>
 
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row mt-4">

        <?php if(!empty($products)): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-4 mt-3">
            <div class="card card-body">
                <div class="">
                    <img src="<?php echo e(asset('/images/products/'.$product['img'])); ?>" class="img-fluid d-block m-auto"
                        style="height: 225px">
                    <div class="font-weight-bold">
                        <?php echo e($product['name']); ?>

                    </div>
                    <div class="font-weight-bold text-info">
                        Rs <?php echo e($product['price']); ?>

                    </div>
                    <div class="font-weight-bold text-info text-center mt-3">
                        <a href="/product/<?php echo e($product['id']); ?>" class="btn btn-info">More Information</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/site/product.blade.php ENDPATH**/ ?>