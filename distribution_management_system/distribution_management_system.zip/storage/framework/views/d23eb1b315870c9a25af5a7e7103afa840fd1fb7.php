

<?php $__env->startSection('content'); ?>


<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page">Category</li>
    </ol>
</nav>

<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#addModal">
    Add New Category
</button>


<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        

        <div class="list-group" id="accordionOne">
            <?php if(!empty($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="expansion-panel list-group-item">
                <a aria-controls="collapse-<?php echo e($item['category_id']); ?>" aria-expanded="false" class="expansion-panel-toggler collapsed"
                    data-toggle="collapse" href="#collapse-<?php echo e($item['category_id']); ?>" id="headingOne">
                    <?php echo e($item['category_name']); ?>

                    <div class="expansion-panel-icon ml-3 text-black-secondary">
                        <i class="collapsed-show material-icons">keyboard_arrow_down</i>
                        <i class="collapsed-hide material-icons">keyboard_arrow_up</i>
                    </div>
                </a>
                <div aria-labelledby="headingOne" class="collapse" data-parent="#accordionOne" id="collapse-<?php echo e($item['category_id']); ?>">
                    <div class="expansion-panel-body">
                        <div>

                            

                            <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#addSubCat-<?php echo e($item['category_id']); ?>">
                                Add Sub Category  
                            </button>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#removeMainCat-<?php echo e($item['category_id']); ?>">
                                Remove Category (<?php echo e($item['category_name']); ?>)
                            </button>

                        </div>
                        <div class="mt-3">
                           
                            <ul class="list-group">
                                <?php $__currentLoopData = $item['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex">
                                    <div>
                                        <?php echo e($subcat['name']); ?>

                                    </div>
                                    <div>
                                    <a href="/dashboard/sub-categories/remove/<?php echo e($subcat['id']); ?>" type="button" class="btn btn-danger btn-sm ml-5"  >
                                            Remove 
                                        </a>
                                    </div>
                                </li> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
 
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

  

<?php if(!empty($categories)): ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="removeMainCat-<?php echo e($item['category_id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Remove Category (<?php echo e($item['category_name']); ?>)</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form action="/dashboard/categories/remove" method="POST" >
                <?php echo csrf_field(); ?>  
                <div class="form-group"> 
                    <input name="category_id"   type="hidden"  value="<?php echo e($item['category_id']); ?>">
                </div> 
                <button type="submit" class="btn btn-success">Remove</button>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>


<div class="modal fade" id="addSubCat-<?php echo e($item['category_id']); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Sub Category (<?php echo e($item['category_name']); ?>)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/dashboard/sub-categories/add" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input name="category_id" type="hidden" value="<?php echo e($item['category_id']); ?>">
                    </div>
                    <div class="form-group">
                        <label>SubCategory Name</label>
                        <input name="name" required type="text" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success">Add</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>



<!-- Add Category -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Add New Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/dashboard/categories/add" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Category Name</label>
                        <input name="name" required type="text" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-success">ADD</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/dashboard/category/index.blade.php ENDPATH**/ ?>