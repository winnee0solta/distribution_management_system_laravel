

<?php $__env->startSection('content'); ?>
 


<div class="container">
    <div class="row mt-4">
        
        <?php if(!empty($products)): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4 mt-3">
                    <div class="card card-body">
                        <div class="">
                            <img src="<?php echo e(asset('/images/products/'.$product['img'])); ?>" class="img-fluid d-block m-auto"
                                style="height: 225px">
                            <div class="font-weight-bold">
                                <?php echo e($product['name']); ?>

                            </div>
                            <div class="font-weight-bold text-info">
                                Rs <?php echo e($product['price']); ?>

                            </div>
                            <div class="font-weight-bold text-info text-center mt-3">
                                <a href="/product/<?php echo e($product['id']); ?>" class="btn btn-info">More Information</a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/site/home.blade.php ENDPATH**/ ?>