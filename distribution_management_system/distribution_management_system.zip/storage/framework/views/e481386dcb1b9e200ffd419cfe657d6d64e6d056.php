<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Annapurna Distributors</title>

    <!-- CSS -->
    <!-- Add Material font (Roboto) and Material icon as needed -->
    <link
        href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i|Roboto+Mono:300,400,700|Roboto+Slab:300,400,700"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</head>

<body>


    <?php echo $__env->yieldContent('modal'); ?>

    <header class="navbar navbar-dark navbar-full bg-warning doc-navbar-default">
        <button id="drawer_switcher" aria-controls="navdrawerDefault" aria-expanded="false"
            aria-label="Toggle Navdrawer" class="navbar-toggler" data-target="#navdrawerDefault"
            data-toggle="navdrawer"><span class="navbar-toggler-icon"></span></button>
        <span class="navbar-brand mr-auto">Annapurna Distributors</span>
        <div>
            <a href="/logout" class="text-white"><i class="material-icons mr-3">logout</i></a>
        </div>
    </header>

    <div aria-hidden="true" class="navdrawer" id="navdrawerDefault" tabindex="-1">
        <div class="navdrawer-content">

            <nav class="navdrawer-nav">
                <a class="nav-item nav-link" href="/dashboard/products">
                    
                    Products
                </a>
                <a class="nav-item nav-link" href="/dashboard/orders">
                    Orders
                </a> 
                <a class="nav-item nav-link" href="/dashboard/categories">
                    Categories
                </a> 
                <a class="nav-item nav-link" href="/dashboard/user">
                    Users
                </a> 

            </nav>
            <div class="navdrawer-divider"></div>

        </div>
    </div>
    
    <div class="container-fluid mt-3">

        <?php echo $__env->yieldContent('content'); ?>

        <div class="mt-5"></div>
    </div>
    






    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/dashboard/layout/base.blade.php ENDPATH**/ ?>