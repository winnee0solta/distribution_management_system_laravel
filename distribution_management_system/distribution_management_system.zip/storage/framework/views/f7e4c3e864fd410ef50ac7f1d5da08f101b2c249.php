

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/cart">Cart</a></li>
        <li class="breadcrumb-item active" aria-current="page">Customer Information</li>
    </ol>
</nav>




<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-5 mt-3">
            <div class="card card-body">
                <form action="/cart/confirm-order" method="POST" >
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                            <label for="exampleInputEmail1">Name</label>
                            <input name="name" type="text" class="form-control" placeholder="Enter Name" value="<?php echo e($clientinfo->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Phone</label>
                            <input name="phone" type="text" class="form-control" placeholder="Enter Phone" value="<?php echo e($clientinfo->phone); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Address</label>
                            <input name="address" type="text" class="form-control" placeholder="Enter Address" value="<?php echo e($clientinfo->address); ?>">
                        </div>
                
                    <div class="text-center mt-3">
                        <button type="submit" class="btn btn-success">confirm order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/site/cart-order-info.blade.php ENDPATH**/ ?>