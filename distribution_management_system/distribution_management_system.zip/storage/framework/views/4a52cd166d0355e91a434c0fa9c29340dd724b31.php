

<?php $__env->startSection('content'); ?>
 


<div class="container">
    <div class="row mt-4">
        
        <?php if(!empty($products)): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4 mt-3">
                    <div class="card card-body">
                        <div class="">
                            <img src="<?php echo e(asset('/images/products/'.$product['img'])); ?>" class="img-fluid d-block m-auto"
                                style="height: 225px">
                            <div class="font-weight-bold">
                                <?php echo e($product['name']); ?>

                            </div>
                            <div class="font-weight-bold text-info">
                                Rs <?php echo e($product['price']); ?>

                            </div>
                            <div >
                                Quantity - <span class="font-weight-bold text-danger">
                                    <?php echo e($product['quantity']); ?>

                                </span>
                            </div>
                            <div >
                                Total - <span class="font-weight-bold text-danger">
                                   Rs <?php echo e($product['quantity'] *  $product['price']); ?>

                                </span>
                            </div>
                            <div class="font-weight-bold text-info text-center mt-3">
                                <a href="/product/<?php echo e($product['product_id']); ?>" target="_blank" class="btn btn-info">More Information</a>
                                <a href="/cart/remove/<?php echo e($product['cart_id']); ?>"   class="btn btn-danger mt-1">Remove From Cart</a>
                            </div> 
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<div class="text-center mt-4">
    <a href="/cart/order-info" target="_blank" class="btn btn-dark mt-1">Proceed to check out </a>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/site/cart.blade.php ENDPATH**/ ?>