

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard/orders">Orders</a></li>
        <li class="breadcrumb-item active" aria-current="page">View</li>
    </ol>
</nav>

<div class="row justify-content-center mt-3">
    <div class="col-md-5">
        <div class="card card-body table-responsive">
            Client Info
            <table class="table">
                <tbody>
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($clientinfo->name); ?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><?php echo e($clientinfo->phone); ?></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td><?php echo e($clientinfo->address); ?></td>
                    </tr>
                    <tr>
                        <td>Order Status</td>
                        <td>
                            <?php if($clientinfo['status'] == 'complete'): ?>
                            <span class="badge badge-pill badge-success px-2 py-1"><?php echo e($clientinfo['status']); ?></span>
                            <?php else: ?>
                            <span class="badge badge-pill badge-danger px-2 py-1"><?php echo e($clientinfo['status']); ?></span>
                            <?php endif; ?>
                        </td> 
                    </tr>
                    <tr>
                        <td colspan="2">
                            <?php if($clientinfo->status == 'incomplete'): ?>
                            <a href="/dashboard/order/<?php echo e($clientinfo['user_id']); ?>/complete"   class="btn btn-danger btn-sm">Mark Order Complete</a>
                            <?php else: ?> 
                            <a href="/dashboard/order/<?php echo e($clientinfo['user_id']); ?>/incomplete" class="btn btn-danger btn-sm">Mark Order Incomplete</a>

                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        <div class="card card-body table-responsive">

            Product Info

            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($orders)): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td>
                        <td>
                            <?php echo e($item['product_name']); ?>

                        </td>
                        <td>
                            Rs <?php echo e($item['price']); ?>

                        </td>
                        <td>
                            <?php echo e($item['quantity']); ?>

                        </td>
                        <td>
                            Rs <?php echo e($item['quantity'] * $item['price']); ?>

                        </td>

                        <td>
                            <div class="d-flex">
                                <a href="/product/<?php echo e($item['product_id']); ?>" target="_blank"
                                    class="btn btn-success btn-sm">View</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="text center mt-5">
    <a href="/dashboard/order/<?php echo e($item['user_id']); ?>/cancel-order" target="_blank" class="btn btn-danger btn-sm">Cancel Order</a>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/dashboard/order/view.blade.php ENDPATH**/ ?>