<h2>Welcome to Dai Call Rental Service.</h2>
<br>
<br>
<h4>
    <a href="<?php echo e(env('APP_URL')); ?>/verify-email?id=<?php echo e($user_id); ?>">Annapurna Distributors</a>
</h4>
<br>
<?php /**PATH F:\WTN\islinton\distribution_management_system\distribution_management_system\resources\views/mail/emailverify.blade.php ENDPATH**/ ?>