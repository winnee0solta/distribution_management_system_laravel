@extends('site.layout.base')

@section('content')

<div class="row justify-content-center mt-4">
    <div class="col-12 col-md-4">
         <p class="h3">
            Verify you email to complete registration.
         </p>
    </div> 
</div>
 
 

@endsection